#!/bin/bash

source /environment
pip install -r "${REQUIREMENTS_FILE}"