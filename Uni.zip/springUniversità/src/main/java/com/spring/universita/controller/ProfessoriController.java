package com.spring.universita.controller;

public class ProfessoriController {

}
