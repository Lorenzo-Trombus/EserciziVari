package com.spring.universita.service;

public class ProfessoriService {

}
