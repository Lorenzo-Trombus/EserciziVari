package com.spring.universita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUniversitaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringUniversitaApplication.class, args);
	}

}
