package com.spring.universita.dao;

public class ProfessoriMappaDAO {

}
