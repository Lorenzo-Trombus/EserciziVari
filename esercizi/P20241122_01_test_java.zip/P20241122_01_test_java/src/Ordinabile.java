import java.util.*;
public interface Ordinabile {
	List<Prodotto> sortByPrice(List<Prodotto> products);	

}
