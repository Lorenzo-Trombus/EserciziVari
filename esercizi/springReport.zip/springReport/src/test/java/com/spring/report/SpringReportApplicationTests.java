package com.spring.report;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
