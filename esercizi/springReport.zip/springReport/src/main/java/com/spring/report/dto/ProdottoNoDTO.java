package com.spring.report.dto;

public class ProdottoNoDTO {

}
