package com.spring.rubrica.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.rubrica.entiity.Venditore;

public interface DAOVenditore extends JpaRepository<Venditore, Integer> {

}
