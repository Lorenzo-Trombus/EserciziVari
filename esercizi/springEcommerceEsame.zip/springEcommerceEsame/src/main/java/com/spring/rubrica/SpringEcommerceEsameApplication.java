package com.spring.rubrica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEcommerceEsameApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEcommerceEsameApplication.class, args);
	}

}
